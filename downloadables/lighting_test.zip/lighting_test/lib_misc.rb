=begin
  EXAMPLE CODE:
  -------------
=end

require 'yaml'
#def string_to_array2d(string) # This doesn't work for some reason
#  return string.split("\n").map {|line| line.each_char.to_a }
#end
def search_directory(folder, search_for=nil)
  result = []
  if search_for != nil then
    search_for = File.join(folder, search_for)
  else
    search_for = folder
  end
  Dir.glob(search_for).each do |file|
    result << file
  end
  return result
end

def string_to_array2d(string)
  array_lines=Array.new
  output=Array.new
  array_row=Array.new
  string.each_line { |line|
    array_lines << line
  }
  array_lines.each { |line|
    array_row=[]
    line.each_char { |char|
      array_row << char
    }
    output << array_row
  }
  return output
end

def array2d_to_string(array)
  output=""
  array.each { |i|
    i.each { |j|
#      if j == nil then
#        output << " "
#      else
        output << j
#      end
    }
  }
  return output
end

def create_2d_array(width, height)
  blankstring = ''
  height.times do
    width.times do
      blankstring << ' '
    end
    blankstring << "\n"
  end
  return string_to_array2d(blankstring)
end

def create_3d_array(width, height, depth)
  result = []
  depth.times do |i|
    result[i] = create_2d_array(width, height)
  end
  return result
end

=begin
def whatisat_string(string, x, y)
  yi = 0
  xi = 0
  string.each do |line|
    if yi == y then
#      puts "found y"
      line.each_char do |char|
        if xi == x then
#          puts "found x"
          return line[char]
        end
        xi += 1
      end
    end
    yi += 1
  end
end
def whatisat_array(array, x, y)
  return array[y][x]
end
def whatisat(string_or_array, x, y)  # x=column number, y=row number
  if string_or_array.class == String then
    whatisat_string(string_or_array, x, y)
  elsif string_or_array.class == Array then
    whatisat_array(string_or_array, x, y)
  else
    puts "ERROR: whatisat was given a non-string non-array!"
    return false
  end
end
#puts whatisat(array, 0, 1).inspect
#puts whatisat(string, 0, 1).inspect
=end

def string_to_array(string) # Why do we need this?
  array_output = Array.new
  string.each do |line|
    line = line.chomp
    array_output << line
  end
  return array_output
end

# Normally it's `rand(integer)`
# Run `srand` before each use, otherwise it'll probably not be random.
def random(min, max)
  # TODO: Ensure we're getting integers.
  # TODO: Allow only one variable to be passed.  In that case return 1..max
  srand
  return (min..max).to_a.sort_by{rand}.pop
end

def randomfloat(min, max)
  # TODO: Ensure we're getting integers.
  # TODO: Allow only one variable to be passed.  In that case return 1..max
  srand
  a = (min..max).to_a.sort_by{rand}.pop
  a = a.to_f / 10.to_f
  return a
end

def file_read(file)
  vputs "Reading file " + file
  # I suspect that there are issues reading files with a space in them.  I'm having a hard time tracking it down though.. TODO: I should adjust the test case.
  if ! File.exists?(file) then
    vputs "That file doesn't exist: "  + file.inspect
    return ""
  end
  # TODO: Check permissions, etc.
# file=file.sub(' ', '_')
  f = File.open(file, 'r')
    string = f.read
  f.close
  return string
end

def yamlfileread(file)
  if ! File.exists?(file) then
    vputs "That file doesn't exist: "  + file.inspect
    return ""
  end

#  return File.open(file, 'r') {|f| YAML.parse(f.read) }
  a = File.open(file, 'r')
  b = YAML::load( a )
  return b
end

# TODO: This can't create a file if it's in a subdirectory that doesn't exist.  I get a TypeError.  Perhaps I could intelligently create the directory..
def create_file(file, file_contents)
  vputs "Creating file: " + file
  # TODO: check that I have write access to my current directory.
  # TODO: check for overwriting an existing file.  Also implement an optional flag to overwrite it.
  begin
    File.open(file, 'w+') do |f|  # open file for update
      f.print file_contents       # write out the example description
    end                           # file is automatically closed
  rescue Exception
    # TODO: Test this under Unix.  Developed under Windows, I can't remove write access to test this code.
# FIXME: This is causing me issues, and I don't know why.. commenting it out for now.
#     raise "Creating the text file #{file.inspect} has failed with: " + Exception
  end
end


def echo(*var)
  puts var
end


def platform()
  if RUBY_PLATFORM == "i386-mingw32" then
    return "windows"
  elsif RUBY_PLATFORM == "i586-linux" then
    return "linux"
  else
    return "I'm not sure how to support this platform!"
  end
end


def getchar()
  if platform() == "windows" then
    require "Win32API"
    Win32API.new("crtdll", "_getch", [], "L").Call
  elsif platform() == "linux" then
    system "stty raw -echo"
    STDIN.getc
  else
    puts "cannot deal with this"
  end
end

def yesno(filetocheck, infotosave, savelocation, thefilename)
  if not File.exists?(filetocheck) then
    create_file(savelocation, infotosave)
  else
    puts "Filename exists, overwrite? [y/N]"
    answer = gets.chomp
    if answer == "y" || answer == "Y" || answer == "yes" || answer == "Yes" then
      create_file(savelocation, infotosave)
      puts "File: " + thefilename + " saved!"
    else
      puts "Filesave Cancelled."
    end
  end
end

def smoother(number, target_number, rate)
  if rate <= 0 then
    puts "smoother rate needs to be positive"
    return 0
  end

  if (number - target_number).abs > rate then
    if number < target_number then
      return (number + rate)
    elsif number > target_number then
      return (number - rate)
    else
      puts "Error in method: smoother"
      return 0
    end
  else
    return target_number
  end
end

# a = getchar()
# Ruby 1.9:
# "e".getbyte(0)               #ASCII to Integer
# puts "you typed " + a.chr
# pause=gets

__END__
