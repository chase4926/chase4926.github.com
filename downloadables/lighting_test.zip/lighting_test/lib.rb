# Our ruby programs will require just this one lib.rb
# This lib.rb will intelligently require all the other libraries in its same directory.
# require 'lib_topic1.rb'

require 'yaml'

def vputs(string)
  # I don't explicitly say == true so as to allow values other than true/false.
  if $VERBOSE == true || $VERBOSE == nil then puts string end
end

def seprubyversion(v1,v2,v3) # Returns "true" on a version at or higher to (v1.v2.v3)
  rubyv = RUBY_VERSION + "."
  a = rubyv.split(".")[0]
  b = rubyv.split(".")[1].split(".")[0]
  c = rubyv.split( b + ".")[1].split(".")[0]
  if not a.to_i < v1 then
    if not b.to_i < v2 then
      if not c.to_i < v3 then
        return true
      end
    end
  else
    return false
  end
end

#vputs "Loading files..."
# Doesn't seem to work at all now, well requiring the files individually isn't THAT hard but this was nice...
=begin
Dir.glob("lib_*.rb").each do |file|
  puts file.inspect
  vputs ".. " + file
  require_relative file
end
=end
#require_relative "lib_*.rb"
#puts Dir.pwd

__END__
