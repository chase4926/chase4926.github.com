#!/usr/bin/env ruby
=begin
TODO List Here / Notes
----------------------
Problem with radius 9 on static light sources
=end

$VERBOSE = true

require_relative 'lib.rb'
require_relative 'lib_misc.rb'
require_relative 'lib_lighting.rb'
require 'yaml'
require 'rubygems'
require 'gosu'
include Gosu


class GameWindow < Gosu::Window
  def initialize
    super(640, 480, false)
    self.caption = "Lighting Test- Survive Engine"
    @grassimage = Gosu::Image.new(self, "mainfiles/media/grass16.png", false)
    @cursor = Cursor.new(self)
    @radius = 128
    @maparray = nil
    @lightfollow = [0,0]
    temp_lighting = Lighting.new(self)
    @preloaded_colors = temp_lighting.get_preloaded_colors()
    temp_lighting = nil
    create_test_map
  end # End GameWindow Initialize

  def update
    @cursor.onmouse(mouse_x, mouse_y)
    if button_down? Gosu::Button::MsLeft then
      @radius += 2
    elsif button_down? Gosu::Button::MsRight then
      @radius -= 2
    end
    @lightfollow[0] = smoother(@lightfollow[0], mouse_x - 8, 1)
    @lightfollow[1] = smoother(@lightfollow[1], mouse_y - 8, 1)
    # Dynamic Lighting
    @maparray.each do |n|
      n.each do |m|
        m.each do |o|
          if o != " " and o != "\n" then
            # All update_light_dynamic 's go here
            o.updatelight('dynamic', @radius.abs, 255, mouse_x - 8, mouse_y - 8, 0)
            o.updatelight('dynamic', 100, 255, @lightfollow[0], @lightfollow[1], 1)
            o.updatecolor(@preloaded_colors)
            # ---
          end
        end
      end
    end
    # ---
  end # End GameWindow Update

  def draw
    @cursor.draw
    @maparray.each do |n|
      n.each do |m|
        m.each do |o|
          if o != " " and o != "\n" then
            o.draw(1)
          end
        end
      end
    end
  end # End GameWindow Draw
  
  def create_test_map()
    @maparray = create_3d_array(1, 40, 40)
    40.times do |height|
      40.times do |width|
        grass = Grass.new(self, @grassimage)
        grass.x = width * 16
        grass.y = height * 16
        @maparray[0][height][width] = grass
      end
    end
    @maparray[0].each do |y|
      y.each do |x|
        x.updatelight( 'static', 160, 255, 32, 32)
        x.updatelight( 'static', 100, 255, 400, 400)
        x.updatelight( 'static', 75, 255, 600, 32)
      end
    end
  end

  def button_down(id)
    if id == Gosu::Button::KbEscape then
      close
    end
  end
end # End GameWindow class


class Cursor
  attr_accessor :x, :y

  def initialize(window)
    @image = Gosu::Image.new(window, "mainfiles/media/cursor.png", false)
    @x = @y = 0.0
  end
  
  def onmouse(mousex, mousey)
    @x = mousex
    @y = mousey
  end

  def draw()
    @image.draw(@x, @y, 150)
  end
end # class Cursor


class Grass < Lighting
  attr_accessor :x, :y
  
  def initialize(window, image)
    @image = image
    @x = @y = 0
    lighting_initialize()
  end
  
  def draw(lighting=0)
    if lighting == 1 then
      @image.draw(@x, @y, 0, 1, 1, @color)
    else
      @image.draw(@x, @y, 0)
    end
  end
end # class Grass


window = GameWindow.new
window.show
